import { app } from "./app";

app.$mount("#app");