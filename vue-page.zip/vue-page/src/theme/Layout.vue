<template>
  <div>
    <app-header></app-header>
      <router-view></router-view>
    <app-footer></app-footer>
  </div>
</template>

<script>
  import AppHeader from "./AppHeader.vue";
  import AppFooter from "./AppFooter.vue";

  export default {
    components: {
      "app-header": AppHeader,
      "app-footer": AppFooter
    },
  }
</script>

<style lang="scss">
  nav {
    display: flex;
    width: 100%;
    background: #eee;
  }

  .flex {
    display: flex;
  }
</style>