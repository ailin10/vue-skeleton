<template>
  <nav class="nav has-shadow">
    <div class="container">
      <router-link to="/" exact>
        <img src="http://bit.ly/vue-img" alt="Vue SPA" />
      </router-link>
      <router-link to="/category/frontend">Frontend</router-link>
      <router-link :to="{name: 'category', params: { id: 'mobile' }}">Mobile</router-link>
      <router-link to="/login">Login</router-link>
    </div>
  </nav>
</template>