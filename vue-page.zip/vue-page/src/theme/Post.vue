<template>
  <div>
    <div class="card-content">
      <slot name="title"></slot>
      <slot name="content"></slot>
    </div>
    <footer class="card-footer">
      <a class="" :href="link" target="_blank">Read more</a>
    </footer>
  </div>
</template>
<script>
  export default {
    props: ["link"]
  }
</script>