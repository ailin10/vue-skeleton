<template>
  <footer class="footer">
    bla bla footer
  </footer>
</template>